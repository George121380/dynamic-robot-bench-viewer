"""Editable, deterministic paper figures of the implemented ACT extensions.

All artwork is vector geometry. No model, training configuration or result is
modified. SVGs retain editable text; outline PDF text for portable font rendering.
"""
import argparse
import math
import random
import re
import xml.etree.ElementTree as E
from pathlib import Path

NS = "http://www.w3.org/2000/svg"
E.register_namespace("", NS)
C = dict(ink="#253448", muted="#677587", line="#CFD7E1", light="#F6F8FA",
         blue="#4C76AA", blue_bg="#EDF3FA", teal="#258A80", teal_bg="#EAF5F1",
         amber="#B17B38", amber_bg="#FBF3E7", violet="#83759F", violet_bg="#F3F0F7")


class Figure:
    def __init__(self, title):
        self.root = E.Element(f"{{{NS}}}svg", {"width":"240mm", "height":"135mm", "viewBox":"0 0 2400 1350", "role":"img"})
        self.count = 0
        E.SubElement(self.root, "title").text = title
        defs = E.SubElement(self.root, "defs")
        for name in ("ink", "blue", "teal", "amber", "muted"):
            marker = E.SubElement(defs, "marker", id="arrow-"+name, viewBox="0 0 12 10", refX="10.5", refY="5", markerWidth="9", markerHeight="8", orient="auto-start-reverse", markerUnits="userSpaceOnUse")
            E.SubElement(marker, "path", d="M 0 0 L 12 5 L 0 10 Z", fill=C[name])
        self.rect(0, 0, 2400, 1350, fill="#FFFFFF", stroke="none", radius=0)

    def el(self, tag, **attrs):
        self.count += 1
        attrs.setdefault("id", "element-"+str(self.count))
        return E.SubElement(self.root, tag, {k.replace("_", "-"):str(v) for k,v in attrs.items()})

    def rect(self, x, y, w, h, fill="#FFFFFF", stroke=None, radius=9, dash=None, width=1.8):
        attrs = dict(x=x,y=y,width=w,height=h,rx=radius,fill=fill,stroke=stroke or C["line"],stroke_width=width)
        if dash: attrs["stroke_dasharray"] = dash
        return self.el("rect", **attrs)

    def text(self, x, y, text, size=25, color="ink", weight=400, anchor="start", italic=False):
        el = self.el("text", x=x,y=y,fill=C.get(color,color),font_family="Arial, Helvetica, sans-serif",font_size=size,font_weight=weight,text_anchor=anchor)
        if italic: el.set("font-style", "italic")
        # Arial does not contain Unicode subscript t. Native SVG spans also
        # keep the mathematical notation editable and searchable in exports.
        cursor=0; previous=None
        for match in re.finditer(r"ₜ|([_^])\{([^}]+)\}",text):
            prefix=text[cursor:match.start()]
            if previous is None:el.text=(el.text or "")+prefix
            else:previous.tail=(previous.tail or "")+prefix
            span=E.SubElement(el,"tspan",{"font-size":str(size*.72),"baseline-shift":"super" if match.group(1)=="^" else "sub"})
            span.text="t" if match.group(0)=="ₜ" else match.group(2)
            previous=span;cursor=match.end()
        if previous is None:el.text=text
        else:previous.tail=text[cursor:]
        return el

    def lines(self, x, y, rows, size=25, color="ink", weight=400, anchor="start", gap=None):
        for i, row in enumerate(rows):
            self.text(x,y+i*(gap or size*1.35),row,size,color,weight,anchor)

    def path(self, d, color="ink", width=2.4, fill="none", dash=None, arrow=False, opacity=1):
        attrs = dict(d=d,fill=fill,stroke=C.get(color,color),stroke_width=width,stroke_linecap="round",stroke_linejoin="round",opacity=opacity)
        if dash: attrs["stroke_dasharray"] = dash
        if arrow: attrs["marker_end"] = "url(#arrow-"+color+")"
        return self.el("path", **attrs)

    def edge(self, points, color="ink", dash=None, width=2.5, arrow=True):
        return self.path("M "+" L ".join(f"{x},{y}" for x,y in points),color,width,dash=dash,arrow=arrow)

    def dot(self, x, y, r=4.5, color="ink", fill=None):
        return self.el("circle",cx=x,cy=y,r=r,fill=fill or C.get(color,color))

    def box(self, x, y, w, h, title, lines=(), tone="blue", title_size=27, body_size=23, dash=None):
        self.rect(x,y,w,h,C[tone+"_bg"],C[tone],dash=dash)
        center=x+w/2
        title_y=y+39 if lines else y+h/2+title_size*.35
        self.text(center,title_y,title,title_size,tone,600,"middle")
        if lines:
            self.lines(center,title_y+36,lines,body_size,"ink",anchor="middle")

    def section(self, x, y, letter, title, color="ink"):
        self.text(x,y,letter,31,color,700)
        self.text(x+45,y,title,31,color,600)

    def tensor(self, x, y, w, h, n=5, tone="blue", vertical=False):
        for i in range(n-1,-1,-1):
            self.rect(x+i*5,y-i*5,w,h,C[tone+"_bg"],C[tone],radius=3,width=1.4)
        if vertical:
            for j in range(1,6):self.path(f"M{x+w*j/6},{y}V{y+h}",tone,.8,opacity=.4)
        else:
            for j in range(1,5):self.path(f"M{x},{y+h*j/5}H{x+w}",tone,.8,opacity=.4)

    def garment(self, x, y, scale=1, tone="blue", tracks=False, points=False):
        # A stylized long-sleeve surface, used only as a schematic input glyph.
        coords=[(0,34),(38,7),(63,0),(78,15),(100,15),(115,0),(140,7),(178,34),(159,73),(133,56),(132,141),(47,141),(46,56),(20,73)]
        d="M"+" L".join(f"{x+px*scale},{y+py*scale}" for px,py in coords)+" Z"
        self.path(d,tone,1.9,fill=C[tone+"_bg"])
        for j in range(1,7):
            yy=y+(23+j*16)*scale
            self.path(f"M{x+48*scale},{yy} Q{x+90*scale},{yy+5*scale} {x+132*scale},{yy}",tone,.8,opacity=.35)
        for j in range(1,6):
            xx=x+(47+j*14)*scale
            self.path(f"M{xx},{y+22*scale} Q{xx+4*scale},{y+82*scale} {xx},{y+140*scale}",tone,.8,opacity=.35)
        if tracks:
            for px,py in [(31,42),(60,59),(92,95),(124,36),(117,125)]:
                xx,yy=x+px*scale,y+py*scale
                self.path(f"M{xx-30*scale},{yy-14*scale} C{xx-12*scale},{yy-20*scale} {xx-16*scale},{yy+10*scale} {xx},{yy}","teal",2.7)
                self.dot(xx,yy,4.5*scale,"teal")
        if points:
            locations=[(53+i*10.5,30+j*20) for j in range(6) for i in range(8)]
            sleeve=[(20,34),(29,27),(38,20),(13,45),(24,48),(34,39),(29,59),(43,47)]
            locations+=sleeve+[(178-px,py) for px,py in sleeve]
            observed=set(random.Random(2026).sample(range(64),16))
            for i,(px,py) in enumerate(locations):
                self.dot(x+px*scale,y+py*scale,3.2*scale,"teal" if i in observed else "amber")

    def camera_frame(self,x,y,w=105,h=78,label=None):
        self.rect(x,y,w,h,C["light"],C["line"],radius=3)
        # Table and two robot-arm outlines contextualize the schematic view.
        self.path(f"M{x+8},{y+h-13}H{x+w-8}","line",1.2)
        self.garment(x+w*.29,y+h*.18,w*.0039,"blue")
        for side in (0,1):
            xx=x+(9 if side==0 else w-9);sgn=1 if side==0 else -1
            self.path(f"M{xx},{y+h-14}L{xx+sgn*9},{y+h-33}L{xx+sgn*23},{y+h-41}L{xx+sgn*30},{y+h-30}","muted",3)
        if label:self.text(x+w/2,y+h+22,label,18,"muted",anchor="middle")

    def save(self,path):
        E.indent(self.root)
        E.ElementTree(self.root).write(path,encoding="utf-8",xml_declaration=True)


def overview():
    f=Figure("Trajectory-conditioned ACT with masked history completion")
    f.text(45,65,"Trajectory-conditioned ACT",43,weight=600)
    f.text(45,108,"Causal RGB and sparse 3D track histories for bimanual garment folding",27,"muted")
    # Compact legend has scientific rather than UI semantics.
    for x,color,label,dash in [(1500,"blue","RGB",None),(1680,"teal","Point tracks",None),(1940,"amber","Training only","8 6")]:
        f.edge([(x,76),(x+55,76)],color,dash)
        f.text(x+68,84,label,23,"muted")
    f.path("M45,143H2355","line",1.4)
    f.section(45,198,"a","Causal observations")
    f.section(545,198,"b","Observation encoding")
    f.section(1140,198,"c","Native ACT policy")
    f.section(1920,198,"d","Action chunk")

    f.text(45,260,"Current RGB",28,"blue",600)
    for i,name in enumerate(["Top","Left","Right"]):f.camera_frame(45+i*124,284,108,81,name)
    f.text(45,418,"RGB history",28,"blue",600)
    for i in range(3):
        for j in range(2,-1,-1):f.camera_frame(45+i*124+j*5,449-j*7,100,75)
    f.text(45,566,"16 frames, 3 views, 0.5 s",23,"muted")
    f.text(45,633,"Current joint state",28,weight=600)
    for i in range(12):f.rect(46+i*29,653,21,39,C["light"],C["line"],radius=2)
    f.text(45,725,"qₜ ∈ ℝ^{12}",25,italic=True)
    f.text(45,790,"Observed cloth tracks",28,"teal",600)
    f.garment(55,818,.91,"teal",tracks=True)
    f.lines(245,845,["K = 16 points","T = 16 times","GT 3D positions"],24,"teal")
    f.text(45,990,"Past and present only",22,"muted",italic=True)

    # Shared visual backbone and two spatial resolutions.
    f.box(545,280,180,276,"ResNet-18",["Shared weights","ImageNet init."],"blue",26,22)
    for i in range(4):f.rect(574+i*25,443-i*10,15,75+i*11,C["blue_bg"],C["blue"],radius=2)
    f.edge([(420,325),(545,325)],"blue")
    f.edge([(420,490),(490,490),(490,492),(545,492)],"blue")
    f.box(770,290,240,112,"Full spatial grid",["3 × 15 × 20 tokens"],"blue",25,22)
    f.box(770,444,240,112,"4 × 4 pooling",["15 × 3 × 16 tokens"],"blue",25,22)
    f.edge([(725,345),(770,345)],"blue")
    f.edge([(725,500),(770,500)],"blue")
    f.text(545,602,"512-D projection + position / time codes",22,"muted")
    f.box(545,642,465,90,"Joint projection",["Normalize, 12 → 512"],"violet",26,23)
    f.edge([(420,675),(545,675)],"ink")
    f.box(545,810,465,112,"Shared trajectory MLP",["One 512-D token per observed point"],"teal",27,23)
    f.edge([(420,865),(545,865)],"teal")
    f.text(550,963,"All observation tokens have width 512",23,"muted")

    # The collector is a concatenation bus, not attention or pooling.
    for yy,color in [(345,"blue"),(500,"blue"),(687,"ink"),(866,"teal")]:
        f.edge([(1010,yy),(1060,yy)],color,arrow=False)
    f.path("M1060,345V866","ink",2)
    f.edge([(1060,575),(1145,575)],"ink")
    f.box(1145,440,180,270,"Observation",["tokens Oₜ"],"blue",25,23)
    for yy,tone in [(555,"blue"),(598,"violet"),(641,"teal")]:
        for j in range(5):f.rect(1164+j*28,yy,19,23,C[tone+"_bg"],C[tone],radius=2,width=1.3)
    f.text(1235,417,"Concatenate",23,"muted",anchor="middle")

    # Training posterior bypasses the auxiliary observation memory entirely.
    f.rect(1145,250,660,126,C["amber_bg"],C["amber"],dash="9 6")
    f.text(1170,287,"CVAE latent",27,"amber",600)
    f.text(1170,321,"Train: posterior from qₜ and GT future actions",23)
    f.text(1170,354,"Evaluate: z = 0                     latent width 32",23)
    f.edge([(1488,376),(1488,440)],"amber",dash="8 6")
    # Native Transformer depth is shown explicitly.
    for dx,dy in [(14,-14),(7,-7),(0,0)]:f.rect(1380+dx,450+dy,195,230,C["blue_bg"],C["blue"],radius=5)
    f.text(1478,512,"ACT encoder",27,"blue",600,"middle")
    f.lines(1478,556,["4 layers","8 heads","d = 512"],25,anchor="middle")
    f.edge([(1325,575),(1380,575)],"ink")
    f.box(1630,450,190,230,"ACT decoder",["1 layer","8 heads","d = 512"],"blue",26,24)
    f.edge([(1590,575),(1630,575)],"ink")
    f.box(1610,762,230,96,"Action queries",["100 learned positions"],"violet",25,21)
    f.edge([(1725,762),(1725,680)],"ink")
    f.text(1380,924,"Native actor, CVAE and action loss retained",23,"muted")

    f.edge([(1820,575),(1910,575)],"ink")
    f.box(1910,450,180,230,"Action head",["512 → 12","Inverse","normalization"],"blue",25,24)
    f.edge([(2090,575),(2140,575)],"ink")
    # Schematic action trajectories, explicitly labelled as output shape.
    f.path("M2140,470V670H2350","line",1.5)
    for j in range(6):
        pts=[]
        for n in range(32):
            x=2148+n*6.2;y=503+j*23+12*math.sin(n/7+j*.5)+3*math.sin(n/3+j)
            pts.append((x,y))
        f.edge(pts,"blue" if j<3 else "teal",width=1.8,arrow=False)
    f.text(2246,718,"Âₜ ∈ ℝ^{100×12}",27,anchor="middle",italic=True)
    f.lines(1920,805,["100 future joint targets","12 output dimensions"],25)
    f.text(1920,890,"Validation: raw action MSE",24,"blue",600)
    f.text(1920,924,"Denormalized targets, MSE in rad²",21,"muted")

    # A distinctly separated training branch, fed before ACT attention.
    f.rect(545,1020,1810,258,C["amber_bg"],C["amber"],radius=9,dash="10 7")
    f.text(570,1058,"e",29,"amber",700)
    f.text(610,1058,"Masked track completion",29,"amber",600)
    f.text(2330,1058,"TRAINING ONLY",22,"amber",600,"end")
    f.box(575,1090,370,96,"Hidden-point queries",["48 current XYZ + 15 past times"],"amber",25,21)
    f.box(1110,1090,240,96,"Memory projection",["Oₜ : 512 → 128"],"amber",24,22)
    f.box(1430,1090,275,96,"Completion decoder",["1 layer, 4 heads, d = 128"],"amber",24,21)
    f.box(1780,1090,255,96,"Past displacements",["48 × 15 × 3"],"amber",24,23)
    f.box(2100,1090,225,96,"Completion loss",["λ · Smooth L1"],"amber",24,23)
    f.edge([(1350,1140),(1430,1140)],"amber")
    f.edge([(1705,1140),(1780,1140)],"amber")
    f.edge([(2035,1140),(2100,1140)],"amber")
    f.edge([(945,1140),(1015,1140),(1015,1220),(1567,1220),(1567,1186)],"amber")
    f.text(1280,1249,"Query MLP: [XYZ, time] → 128",21,"amber",anchor="middle")
    f.text(2100,1249,"GT hidden past motion",21,"amber")
    f.edge([(2215,1224),(2215,1186)],"amber")
    # Observation-only tap: no posterior latent and no ACT attention output.
    f.dot(1235,710,5.5,"amber")
    f.edge([(1235,710),(1235,1090)],"amber",dash="8 6")
    f.lines(1256,820,["Pre-Transformer tap","Latent excluded"],21,"amber")
    f.lines(45,1056,["Observed tracks:","actor input","Hidden tracks:","auxiliary targets only"],23,"muted",gap=34)
    f.text(45,1234,"L = L_{action} + 10 L_{KL} + λ L_{comp}",23,italic=True)
    f.path("M45,1304H2355","line",1.3)
    f.text(45,1334,"Blue / teal: actor inputs     Amber: training-only computation",22,"muted")
    f.text(2355,1334,"Auxiliary gradients update observation encoders / projections, not the main ACT Transformer directly",21,"muted",anchor="end")
    return f


def details():
    f=Figure("Trajectory encoder, controlled baselines, and residual completion control")
    f.text(45,65,"Trajectory encoding and experimental controls",43,weight=600)
    f.text(45,108,"Implemented design: fixed causal windows, shared ACT core and an auxiliary-gradient control",27,"muted")
    f.path("M45,143H2355","line",1.4)
    f.section(45,198,"a","Point-wise trajectory representation","teal")
    f.section(1550,198,"b","Observed / hidden point split","teal")
    f.path("M1495,230V705","line",1.4)

    # Three individual trajectories and their aligned causal slots.
    f.text(45,256,"Persistent point identities within each window",24,"muted")
    for i in range(3):
        yy=330+i*102
        f.text(45,yy+9,"Point "+str(i+1),23,"teal",600)
        pts=[]
        for j in range(16):
            xx=160+j*15;py=yy+13*math.sin(j/4+i)
            pts.append((xx,py))
        f.edge(pts,"teal",width=2.2,arrow=False)
        for j,(xx,py) in enumerate(pts):f.dot(xx,py,3.2,"teal",C["teal"] if j==15 else "#C9E6DE")
    f.text(163,626,"t − 0.5 s",22,"muted")
    f.text(387,626,"t",24,"teal",600,"middle")
    f.text(45,678,"K = 16 trajectories, T = 16 slots",24,"teal",600)
    f.edge([(422,430),(500,430)],"teal")
    f.rect(500,280,410,305,C["teal_bg"],C["teal"])
    f.text(705,322,"8-D feature at each time",27,"teal",600,"middle")
    feature_rows=[("Current XYZ / 0.5 m","3"),("Past − current XYZ / 0.05 m","3"),("Relative time","1"),("Validity mask","1")]
    for i,(label,n) in enumerate(feature_rows):
        yy=376+i*48
        f.text(524,yy,label,23)
        f.text(884,yy,n,23,"teal",600,"end")
    f.text(705,625,"Invalid slots are zeroed",22,"muted",anchor="middle")
    f.edge([(910,430),(970,430)],"teal")
    # Show actual Linear/ReLU stages rather than an opaque encoder box.
    for x,label in [(970,"128"),(1110,"128"),(1250,"512")]:
        f.tensor(x,338,85,188,3,"teal",True)
        f.text(x+43,570,label,25,"teal",600,"middle")
    f.edge([(1065,430),(1105,430)],"teal")
    f.edge([(1205,430),(1245,430)],"teal")
    f.text(1087,316,"ReLU",20,"muted",anchor="middle")
    f.text(1227,316,"ReLU",20,"muted",anchor="middle")
    f.text(1160,626,"Shared MLP across points",24,"teal",600,"middle")
    f.text(1160,663,"16 × 8 flattened to 128 inputs",22,"muted",anchor="middle")
    f.text(1160,698,"K × 512 tokens, 99,072 parameters",23,"teal",anchor="middle")

    f.garment(1570,272,1.65,"teal",points=True)
    f.text(1940,286,"Current visible surface",24,weight=600)
    f.lines(1940,330,["Farthest-point sampling","64 candidate vertices","Seeded random split"],24,"muted",gap=38)
    f.edge([(1960,443),(1960,482),(1840,482),(1840,530)],"teal")
    f.edge([(1960,482),(2180,482),(2180,530)],"amber")
    f.box(1680,530,310,106,"16 observed points",["Past XYZ enters the actor"],"teal",25,22)
    f.box(2030,530,310,106,"48 hidden points",["Train-only queries / targets"],"amber",25,20)
    f.text(1550,694,"Resample identities across windows, retain identity across time",22,"muted")
    f.path("M45,747H2355","line",1.4)
    f.section(45,807,"c","Matched observation controls")
    f.section(1220,807,"d","3NN residual completion control","amber")

    # A research comparison matrix with native vector text, no screenshot.
    xs=[45,370,575,790,1010]; top=865
    f.text(45,850,"Every condition uses current RGB and current joint state",23,"muted")
    headers=["Condition","RGB history","Current XYZ","Past motion","Aux. loss"]
    for x,label in zip(xs,headers):f.text(x,top+25,label,23,weight=600)
    f.path("M45,908H1165","ink",1.4)
    rows=[("ACT","—","—","—","—"),("RGB-H","16 frames","—","—","—"),("Geometry","16 frames","✓","—","—"),("Tracks","16 frames","✓","✓","—"),("Tracks + Completion","16 frames","✓","✓","✓")]
    for i,row in enumerate(rows):
        yy=950+i*58
        if i==4:f.rect(35,yy-33,1130,53,C["amber_bg"],"none",radius=0)
        for j,(x,label) in enumerate(zip(xs,row)):
            tone="teal" if j in (2,3) and label=="✓" else "amber" if j==4 and label=="✓" else "ink"
            f.text(x,yy,label,25 if j==0 else 24,tone,600 if j==0 else 400)
        f.path(f"M45,{yy+18}H1165","line",.8)
    f.lines(45,1280,["T = 16 at stride 3, 90 Hz. Predict 100 joint targets in every condition.","History-enabled variants share the RGB window. GT point tracks are privileged inputs."],22,"muted",gap=31)

    # The residual variant changes only the train-time completion predictor.
    f.text(1220,850,"Same actor inputs and architecture in both variants",23,"muted")
    f.box(1235,889,240,96,"Observed tracks",["+ hidden current XYZ"],"teal",24,21)
    f.box(1550,889,240,96,"3NN interpolation",["Inverse squared distance"],"teal",24,20)
    f.edge([(1475,937),(1550,937)],"teal")
    f.edge([(1790,937),(2210,937),(2210,1073)],"teal")
    f.text(1990,920,"Fixed displacement prior",22,"teal",anchor="middle")
    f.box(1235,1040,240,96,"Observation Oₜ",["Before ACT attention"],"amber",24,21)
    f.box(1550,1040,240,96,"Gradient switch",["Connected / stop-grad"],"amber",24,21)
    f.edge([(1475,1088),(1550,1088)],"amber")
    f.box(1850,1040,240,96,"Residual decoder",["Learned displacement"],"amber",24,21)
    f.edge([(1790,1088),(1850,1088)],"amber")
    f.edge([(2090,1088),(2186,1088)],"amber")
    f.dot(2210,1088,24,"amber",C["amber_bg"])
    f.el("circle",cx=2210,cy=1088,r=24,fill="none",stroke=C["amber"],stroke_width=2)
    f.text(2210,1098,"+",34,"amber",anchor="middle")
    f.text(2139,1068,"× 0.1",21,"amber",anchor="middle")
    f.edge([(2234,1088),(2320,1088),(2320,1195),(1830,1195)],"amber")
    f.text(2140,1175,"Predicted hidden past motion",22,"amber",anchor="middle")
    f.box(1510,1150,320,96,"Masked Smooth L1",["GT hidden past displacements"],"amber",24,21)
    f.lines(1235,1290,["Connected: auxiliary gradients reach shared observation encoders.","Detached: the auxiliary head learns, with its memory input detached."],22,"muted",gap=31)
    return f


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    overview().save(args.output/"architecture-overview.svg")
    details().save(args.output/"architecture-details.svg")
    print(args.output)


if __name__ == "__main__":main()
